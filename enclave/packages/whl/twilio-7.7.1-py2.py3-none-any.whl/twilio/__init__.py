
__version_info__ = ('7', '7', '1')
__version__ = '.'.join(__version_info__)
