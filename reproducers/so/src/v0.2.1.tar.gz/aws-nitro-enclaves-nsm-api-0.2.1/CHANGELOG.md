# 0.2.1

Fixes:
* build container on other distros than Amazon Linux 2
* build container permissions
* nsm-lib header generation

Updates:
* default build container rust version to 1.58.1
* cbindgen to 0.21

# 0.2.0

* Added top level crate
* Reorganize nsm-driver and nsm-io into top level crate
* Changed authors in Cargo.toml
